<?php

require_once dirname(__FILE__).'/../../../core/php/core.inc.php';

function okofen_install() {

}

function okofen_update() {

}

function okofen_remove() {

}

